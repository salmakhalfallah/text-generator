import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * character distribution class for each string in the map
 */
public class CharDistribution
{
    // this str object is the initial string. if a string is never found in the text.
    // this string will be incremented with new characters everytime a next chara
    String str = "";

    public void occurs(char c)
    {
       str = str + c;
    }

    public char getRand()
    {
        // Use this code to generate a random character in the string!
        Random random = ThreadLocalRandom.current();
        return str.charAt(random.nextInt(str.length()));
    }
}
