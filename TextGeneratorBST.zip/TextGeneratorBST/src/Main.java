import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args) throws IOException {
        // creating a new binary search tree
        BST BinarySearchTree = new BST();

        // inputting the input text file
        File file = new File("merchant.txt");
        Scanner input = new Scanner(System.in);

        // inputting the window size from the user
        System.out.println("Please input a window size: ");
        int substringLength = input.nextInt();
        int textLength = 0;

        try (Scanner fileReader = new Scanner(file))
        {
            StringBuilder contentBuilder = new StringBuilder();

            // reading the entire file content into a single string
            while (fileReader.hasNextLine())
            {
                contentBuilder.append(fileReader.nextLine()).append(" ");
            }

            // grabbing the total length of the entire text to use in the while loop
            String content = contentBuilder.toString().trim();
            int totalLength = content.length();
            textLength = content.length();
            int i = 0;

            // extracting substrings of window size
            while(i < totalLength)
            {
                int end = Math.min(i + substringLength, totalLength);
                String substring = content.substring(i, end);
                System.out.println(substring);

                // grabbing the next character after the substring
                if(end < totalLength)
                {
                    char nextChar = content.charAt(end);
                    System.out.println("Next: " + nextChar);

                    // inserting both the substring and the next character into the binary search tree
                    BinarySearchTree.insert(substring, nextChar);
                }
                i ++;
            }
            

        } catch (FileNotFoundException e)
        {
            System.err.println("File not found: " + e.getMessage());
        }

        // grabbing the first character in the text from the bst and starting the new output
        String window = BinarySearchTree.getRoot();
        String newText = window;

        /**
         * this while loop does the following:
         * 1. grabbing the character distribution object from the window str after searching for it in the bst
         * 2. using the character distribution object to generate a next random character
         * 3. inputting the next random character into the new text
         * 4. incrementing the window to find the next window in the bst
         */
        while(newText.length() < textLength)
        {
            CharDistribution charDist = BinarySearchTree.search(window);
            char ran = charDist.getRand();
            window = window + ran;
            newText = newText + ran;
            window = window.substring(1, substringLength + 1);
        }

        // outputting the final new text
        System.out.print(newText + " is the current new text.");

    }
}
