public class BST
{
    private class Node
    {
        String key;
        CharDistribution charDistribution;
        Node left;
        Node right;

        public Node(String k, CharDistribution newDist)
        {
            key = k;
            charDistribution = newDist;
            left = null;
            right = null;
        }
    }

    Node root;
    public BST()
    {
        root = null;
    }

    public void insert(String newStr, char c)
    {
        if(root == null)
        {
            root = new Node(newStr, new CharDistribution());
            root.charDistribution.occurs(c);
            System.out.println("The root of the tree is: " + newStr);
        }
        else
        {
            insertRec(root, newStr, c);
        }
    }

    private void insertRec(Node root, String newStr, char c)
    {
        if(root.key.compareTo(newStr) > 0)
        {
            System.out.println(root.key + " is greater lexicographically to " + newStr);
            if(root.left == null)
            {
                root.left = new Node(newStr, new CharDistribution());
                root.left.charDistribution.occurs(c);
                System.out.println("Node " + newStr + " added.");
            }
            else
            {
                insertRec(root.left, newStr, c);
            }

        }
        else if(root.key.compareTo(newStr) < 0)
        {
            System.out.println(root.key + " is lexicographically less than " + newStr );
            if(root.right == null)
            {
                root.right = new Node(newStr, new CharDistribution());
                root.right.charDistribution.occurs(c);
                System.out.println("Node " + newStr + " added.");
            }
            else
            {
                insertRec(root.right, newStr, c);
            }
        }
        else if(root.key.compareTo(newStr) == 0)
        {
            System.out.println(root.key + " is equal to " + newStr);
            System.out.println("Node " + newStr + " found.");
            root.charDistribution.occurs(c);
        }
    }

    public CharDistribution search(String str)
    {
        if(root == null)
        {
            System.out.println("Searching an empty tree?? Girl u dumb for that.");
            return null;
        }
        else
        {
            return searchRec(root, str);
        }

    }

    private CharDistribution searchRec(Node root, String str)
    {
        if(root == null)
        {
            System.out.println("Element not found.");
            return null;
        }

        if(root.key.compareTo(str) == 0)
        {
            System.out.println("The key " + root.key + " equals to the string: " + str);
            return root.charDistribution;
        }
        else if(root.key.compareTo(str) > 0)
        {
            System.out.println(root.key + " is lexicographically greater than " + str);
            return searchRec(root.left, str);
        }
        else
        {
            System.out.println(root.key + " is lexicographically less than " + str);
            return searchRec(root.right, str);
        }
    }

    public boolean contains(String str)
    {

        if(search(str) == null)
        {
            return false;
        }

        return true;
    }

    public String getRoot()
    {
        return root.key;
    }

    public boolean empty()
    {
        if(root == null)
            return true;

        return false;
    }
}
